"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { CreditCard, DollarSign, TreesIcon as Tree, Calendar, Gift, Heart } from "lucide-react"
import { ProjectCard } from "@/components/project-card"

// Mock data for projects
const projects = [
  {
    id: "p1",
    title: "Amazon Rainforest Restoration",
    description: "Help restore the lungs of our planet by planting trees in the Amazon rainforest.",
    location: "Brazil",
    image: "/placeholder.svg?height=200&width=300",
    progress: 78,
    treesPlanted: 15600,
    treesGoal: 20000,
  },
  {
    id: "p2",
    title: "Borneo Orangutan Habitat",
    description: "Plant trees to restore the natural habitat of endangered orangutans in Borneo.",
    location: "Indonesia",
    image: "/placeholder.svg?height=200&width=300",
    progress: 45,
    treesPlanted: 9000,
    treesGoal: 20000,
  },
  {
    id: "p3",
    title: "California Wildfire Recovery",
    description: "Help California recover from devastating wildfires by replanting native trees.",
    location: "United States",
    image: "/placeholder.svg?height=200&width=300",
    progress: 62,
    treesPlanted: 12400,
    treesGoal: 20000,
  },
]

export default function DonatePage() {
  const { toast } = useToast()
  const [donationType, setDonationType] = useState("one-time")
  const [donationAmount, setDonationAmount] = useState("25")
  const [customAmount, setCustomAmount] = useState("")
  const [selectedProject, setSelectedProject] = useState("all")
  const [isProcessing, setIsProcessing] = useState(false)
  const [isRecurring, setIsRecurring] = useState(false)
  const [donationCompleted, setDonationCompleted] = useState(false)
  const [donationDetails, setDonationDetails] = useState<{
    amount: string
    trees: number
    project?: string
  } | null>(null)

  const handleDonationSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)

    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false)
      setDonationCompleted(true)

      const amount = customAmount || donationAmount
      const trees = Math.floor(Number(amount) / 3.5)
      const projectName =
        selectedProject === "all"
          ? "Global Reforestation Fund"
          : projects.find((p) => p.id === selectedProject)?.title || "Unknown Project"

      setDonationDetails({
        amount,
        trees,
        project: projectName,
      })

      toast({
        title: "Donation Successful",
        description: `Thank you for your donation of $${amount}. You've helped plant ${trees} trees!`,
      })
    }, 2000)
  }

  return (
    <div className="container py-12">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Plant Trees, Change Lives</h1>
          <p className="text-gray-500 mt-2">Your donation directly supports reforestation projects around the world</p>
        </div>

        {!donationCompleted ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Make a Donation</CardTitle>
                  <CardDescription>Choose how you'd like to contribute to reforestation efforts</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleDonationSubmit} className="space-y-6">
                    <div className="space-y-4">
                      <Label>Donation Type</Label>
                      <RadioGroup
                        value={donationType}
                        onValueChange={setDonationType}
                        className="grid grid-cols-2 gap-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="one-time" id="one-time" />
                          <Label htmlFor="one-time" className="flex items-center">
                            <DollarSign className="mr-2 h-4 w-4 text-primary" />
                            One-time Donation
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="monthly" id="monthly" onClick={() => setIsRecurring(true)} />
                          <Label htmlFor="monthly" className="flex items-center">
                            <Calendar className="mr-2 h-4 w-4 text-primary" />
                            Monthly Donation
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="gift" id="gift" />
                          <Label htmlFor="gift" className="flex items-center">
                            <Gift className="mr-2 h-4 w-4 text-primary" />
                            Gift a Donation
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="corporate" id="corporate" />
                          <Label htmlFor="corporate" className="flex items-center">
                            <Heart className="mr-2 h-4 w-4 text-primary" />
                            Corporate Giving
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="space-y-4">
                      <Label>Donation Amount</Label>
                      <RadioGroup
                        value={donationAmount}
                        onValueChange={(value) => {
                          setDonationAmount(value)
                          if (value !== "custom") setCustomAmount("")
                        }}
                        className="grid grid-cols-2 sm:grid-cols-4 gap-4"
                      >
                        <div className="flex items-center justify-center">
                          <RadioGroupItem value="10" id="amount-10" className="sr-only" />
                          <Label
                            htmlFor="amount-10"
                            className={`flex h-14 w-full cursor-pointer items-center justify-center rounded-md border-2 ${
                              donationAmount === "10" ? "border-primary bg-primary/10" : "border-muted"
                            }`}
                          >
                            $10
                          </Label>
                        </div>
                        <div className="flex items-center justify-center">
                          <RadioGroupItem value="25" id="amount-25" className="sr-only" />
                          <Label
                            htmlFor="amount-25"
                            className={`flex h-14 w-full cursor-pointer items-center justify-center rounded-md border-2 ${
                              donationAmount === "25" ? "border-primary bg-primary/10" : "border-muted"
                            }`}
                          >
                            $25
                          </Label>
                        </div>
                        <div className="flex items-center justify-center">
                          <RadioGroupItem value="50" id="amount-50" className="sr-only" />
                          <Label
                            htmlFor="amount-50"
                            className={`flex h-14 w-full cursor-pointer items-center justify-center rounded-md border-2 ${
                              donationAmount === "50" ? "border-primary bg-primary/10" : "border-muted"
                            }`}
                          >
                            $50
                          </Label>
                        </div>
                        <div className="flex items-center justify-center">
                          <RadioGroupItem value="100" id="amount-100" className="sr-only" />
                          <Label
                            htmlFor="amount-100"
                            className={`flex h-14 w-full cursor-pointer items-center justify-center rounded-md border-2 ${
                              donationAmount === "100" ? "border-primary bg-primary/10" : "border-muted"
                            }`}
                          >
                            $100
                          </Label>
                        </div>
                        <div className="col-span-2 sm:col-span-4">
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="custom" id="amount-custom" />
                            <Label htmlFor="amount-custom" className="flex-1">
                              <div className="flex items-center">
                                <span className="mr-2">Custom Amount:</span>
                                <div className="relative flex-1">
                                  <DollarSign className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                                  <Input
                                    type="number"
                                    min="1"
                                    placeholder="Enter amount"
                                    className="pl-8"
                                    value={customAmount}
                                    onChange={(e) => {
                                      setCustomAmount(e.target.value)
                                      setDonationAmount("custom")
                                    }}
                                  />
                                </div>
                              </div>
                            </Label>
                          </div>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="space-y-4">
                      <Label htmlFor="project">Choose a Project</Label>
                      <Select value={selectedProject} onValueChange={setSelectedProject}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a project" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Global Reforestation Fund</SelectItem>
                          {projects.map((project) => (
                            <SelectItem key={project.id} value={project.id}>
                              {project.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="pt-4 border-t">
                      <h3 className="font-medium mb-4">Payment Information</h3>

                      <Tabs defaultValue="card">
                        <TabsList className="grid w-full grid-cols-3">
                          <TabsTrigger value="card">Credit Card</TabsTrigger>
                          <TabsTrigger value="paypal">PayPal</TabsTrigger>
                          <TabsTrigger value="apple">Apple Pay</TabsTrigger>
                        </TabsList>

                        <TabsContent value="card" className="space-y-4 mt-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div className="col-span-2">
                              <Label htmlFor="card-name">Cardholder Name</Label>
                              <Input id="card-name" placeholder="John Doe" className="mt-1" />
                            </div>
                            <div className="col-span-2">
                              <Label htmlFor="card-number">Card Number</Label>
                              <div className="relative mt-1">
                                <CreditCard className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                                <Input id="card-number" placeholder="1234 5678 9012 3456" className="pl-8" />
                              </div>
                            </div>
                            <div>
                              <Label htmlFor="expiry">Expiry Date</Label>
                              <Input id="expiry" placeholder="MM/YY" className="mt-1" />
                            </div>
                            <div>
                              <Label htmlFor="cvc">CVC</Label>
                              <Input id="cvc" placeholder="123" className="mt-1" />
                            </div>
                          </div>
                        </TabsContent>

                        <TabsContent value="paypal" className="mt-4">
                          <div className="text-center py-8 bg-gray-50 rounded-md">
                            <p className="text-gray-500 mb-4">
                              You will be redirected to PayPal to complete your donation.
                            </p>
                            <Button type="button" variant="outline">
                              Continue with PayPal
                            </Button>
                          </div>
                        </TabsContent>

                        <TabsContent value="apple" className="mt-4">
                          <div className="text-center py-8 bg-gray-50 rounded-md">
                            <p className="text-gray-500 mb-4">Complete your donation with Apple Pay.</p>
                            <Button type="button" variant="outline">
                              Pay with Apple Pay
                            </Button>
                          </div>
                        </TabsContent>
                      </Tabs>
                    </div>

                    {isRecurring && (
                      <div className="flex items-center space-x-2">
                        <Checkbox id="recurring" checked={true} />
                        <label
                          htmlFor="recurring"
                          className="text-sm text-gray-500 leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          I understand this is a recurring monthly donation that will continue until canceled.
                        </label>
                      </div>
                    )}

                    <div className="flex items-center space-x-2">
                      <Checkbox id="terms" />
                      <label
                        htmlFor="terms"
                        className="text-sm text-gray-500 leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        I agree to the terms and conditions and privacy policy.
                      </label>
                    </div>

                    <Button type="submit" className="w-full bg-primary hover:bg-primary/90" disabled={isProcessing}>
                      {isProcessing ? (
                        <>
                          <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                          Processing...
                        </>
                      ) : (
                        `Donate ${donationAmount === "custom" ? `$${customAmount}` : `$${donationAmount}`}`
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Your Impact</CardTitle>
                  <CardDescription>See the difference your donation will make</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-green-50 p-4 rounded-md">
                    <div className="flex items-center mb-2">
                      <Tree className="h-5 w-5 text-green-600 mr-2" />
                      <h3 className="font-medium">Trees Planted</h3>
                    </div>
                    <p className="text-3xl font-bold">{Math.floor(Number(customAmount || donationAmount) / 3.5)}</p>
                    <p className="text-sm text-gray-500">Each tree costs approximately $3.50 to plant and maintain</p>
                  </div>

                  <div>
                    <h3 className="font-medium mb-2">Environmental Benefits</h3>
                    <ul className="text-sm text-gray-500 space-y-2">
                      <li className="flex items-start">
                        <span className="mr-2">•</span>
                        <span>
                          Absorbs approximately {Math.floor(Number(customAmount || donationAmount) / 3.5) * 25}kg of CO₂
                          per year
                        </span>
                      </li>
                      <li className="flex items-start">
                        <span className="mr-2">•</span>
                        <span>Provides habitat for wildlife</span>
                      </li>
                      <li className="flex items-start">
                        <span className="mr-2">•</span>
                        <span>Prevents soil erosion</span>
                      </li>
                      <li className="flex items-start">
                        <span className="mr-2">•</span>
                        <span>Improves air and water quality</span>
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-medium mb-2">Social Benefits</h3>
                    <ul className="text-sm text-gray-500 space-y-2">
                      <li className="flex items-start">
                        <span className="mr-2">•</span>
                        <span>Creates jobs in local communities</span>
                      </li>
                      <li className="flex items-start">
                        <span className="mr-2">•</span>
                        <span>Provides sustainable income sources</span>
                      </li>
                      <li className="flex items-start">
                        <span className="mr-2">•</span>
                        <span>Supports indigenous land rights</span>
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        ) : (
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                <Tree className="h-8 w-8 text-green-600" />
              </div>
              <CardTitle className="text-2xl">Thank You for Your Donation!</CardTitle>
              <CardDescription>Your contribution is making a real difference for our planet</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-gray-50 p-4 rounded-md">
                  <p className="text-sm text-gray-500">Amount Donated</p>
                  <p className="text-2xl font-bold">${donationDetails?.amount}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-md">
                  <p className="text-sm text-gray-500">Trees Planted</p>
                  <p className="text-2xl font-bold">{donationDetails?.trees}</p>
                </div>
              </div>

              <div className="bg-green-50 p-4 rounded-md">
                <h3 className="font-medium mb-2">Donation Details</h3>
                <p className="text-sm text-gray-600">
                  Your donation to <strong>{donationDetails?.project}</strong> will help plant {donationDetails?.trees}{" "}
                  trees, which will absorb approximately {(donationDetails?.trees || 0) * 25}kg of CO₂ per year.
                </p>
              </div>

              <div className="text-center space-y-4">
                <p className="text-sm text-gray-500">A receipt has been sent to your email address.</p>
                <div className="flex flex-wrap justify-center gap-4">
                  <Button variant="outline">
                    <Gift className="mr-2 h-4 w-4" />
                    Share with Friends
                  </Button>
                  <Button className="bg-primary hover:bg-primary/90" onClick={() => setDonationCompleted(false)}>
                    Make Another Donation
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="mt-16">
          <h2 className="text-2xl font-bold mb-6">Featured Projects</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {projects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

